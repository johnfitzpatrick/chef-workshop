name 'example'
description 'An example cookbook'
version '1.0.0'
